﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment1
{
	/// <summary>
	/// Static class containing methods for special string filtering.
	/// </summary>
	public static class CombinedExpressionUtils
	{
		/// <summary>
		/// Filters the specified collection of string so that only those are returned that are composed of 
		/// two concatenated smaller strings also found in the collection.
		/// </summary>
		/// <param name="expressions">The list of expressions</param>
		/// <param name="lengthFilter">If specified, only matches of this length will be returned</param>
		/// <returns></returns>
		public static List<string> FilterCombinedExpressions(IEnumerable<string> expressions, int lengthFilter) // The expressions list is IEnumerable so that it can accept for Arrays, Lists and other kinds of collections.
		{
			// Length filtering is the first step, because filtering elements at this points gives us fewer elements to work with, thus resulting in better performance.
			IEnumerable<string> longStrings = expressions.Where(ex => ex.Length == lengthFilter);
			
			// Preparing a separate list of shortStrings. I use List here so that I can utilize its powerful methods such as .Find() later on.
			List<string> shortStrings = expressions
				.Except(longStrings)
				.Where(ex => ex.Length > 0 && ex.Length < lengthFilter)
				.ToList();

			List<string> matches = new List<string>();

			foreach (string shortString in shortStrings)
			{
				foreach (string longString in longStrings)
				{
					// If we have already found this long string to be a match when examining a previous short string, 
					// then we just skip it to spare the CPU and to save trees.
					if (matches.Contains(longString))
						continue;

					bool isMatch = false;

					if (longString.StartsWith(shortString))
					{
						// List.Find is a fast and easy-to-use Linq feature, no point writing our own filtering logic here.
						isMatch = shortStrings.Find(s => longString.EndsWith(s)) != null;
					}
					else if (longString.EndsWith(shortString))
					{
						isMatch = shortStrings.Find(s => longString.StartsWith(s)) != null;
					}

					if (isMatch)
						matches.Add(longString);
				}
			}

			return matches;
		}
	}
}
