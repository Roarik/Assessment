﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Assessment1;

namespace Assessment1Tests
{
	[TestClass]
	public class CombinedExpressionUtilsTest
	{
		[TestMethod]
		[Timeout(1000)]
		public void FilterExpressions()
		{
			// Arrange - setting up data required for testing
			List<string> expressions = new List<string>()
			{
				"al", "albums", "aver", "bar", "barely", "be", "befoul", "bums", "by", "cat", "con", "convex", "ely", "foul", "here", "hereby", "jig", "jigsaw", "or", "saw", "tail", "tailor", "vex", "we", "weaver"
			};
			List<string> expectedResults = new List<string>()
			{
				"albums", "weaver", "barely", "befoul", "hereby", "convex", "jigsaw", "tailor"
			};
			int lengthFilter = 6;

			// Act
			List<string> results = CombinedExpressionUtils.FilterCombinedExpressions(expressions, lengthFilter);

			// Assess
			CollectionAssert.AreEqual(results, expectedResults);
		}
	}
}
