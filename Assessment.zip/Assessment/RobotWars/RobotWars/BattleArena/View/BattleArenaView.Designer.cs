﻿namespace RobotWars
{
	partial class RobotWarView
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.tbBattleLog = new System.Windows.Forms.TextBox();
			this.btnRunSimulation = new System.Windows.Forms.Button();
			this.laBattleLogCaption = new System.Windows.Forms.Label();
			this.panelBattleArena = new System.Windows.Forms.Panel();
			this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
			this.panelBattleLog = new System.Windows.Forms.Panel();
			this.panelBottom = new System.Windows.Forms.Panel();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.label1 = new System.Windows.Forms.Label();
			this.panelBattleArena.SuspendLayout();
			this.panelBattleLog.SuspendLayout();
			this.panelBottom.SuspendLayout();
			this.SuspendLayout();
			// 
			// tbBattleLog
			// 
			this.tbBattleLog.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.tbBattleLog.Location = new System.Drawing.Point(0, 31);
			this.tbBattleLog.Multiline = true;
			this.tbBattleLog.Name = "tbBattleLog";
			this.tbBattleLog.ReadOnly = true;
			this.tbBattleLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.tbBattleLog.Size = new System.Drawing.Size(254, 441);
			this.tbBattleLog.TabIndex = 1;
			// 
			// btnRunSimulation
			// 
			this.btnRunSimulation.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.btnRunSimulation.Location = new System.Drawing.Point(440, 12);
			this.btnRunSimulation.Name = "btnRunSimulation";
			this.btnRunSimulation.Size = new System.Drawing.Size(75, 23);
			this.btnRunSimulation.TabIndex = 2;
			this.btnRunSimulation.Text = "Run";
			this.btnRunSimulation.UseVisualStyleBackColor = true;
			this.btnRunSimulation.Click += new System.EventHandler(this.btnRunSimulation_Click);
			// 
			// laBattleLogCaption
			// 
			this.laBattleLogCaption.AutoSize = true;
			this.laBattleLogCaption.Dock = System.Windows.Forms.DockStyle.Top;
			this.laBattleLogCaption.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.laBattleLogCaption.Location = new System.Drawing.Point(0, 0);
			this.laBattleLogCaption.Name = "laBattleLogCaption";
			this.laBattleLogCaption.Size = new System.Drawing.Size(84, 18);
			this.laBattleLogCaption.TabIndex = 3;
			this.laBattleLogCaption.Text = "Battle Log";
			this.laBattleLogCaption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panelBattleArena
			// 
			this.panelBattleArena.Controls.Add(this.flowLayoutPanel);
			this.panelBattleArena.Location = new System.Drawing.Point(12, 64);
			this.panelBattleArena.Name = "panelBattleArena";
			this.panelBattleArena.Size = new System.Drawing.Size(651, 472);
			this.panelBattleArena.TabIndex = 4;
			// 
			// flowLayoutPanel
			// 
			this.flowLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.flowLayoutPanel.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.flowLayoutPanel.Location = new System.Drawing.Point(0, 0);
			this.flowLayoutPanel.Name = "flowLayoutPanel";
			this.flowLayoutPanel.Size = new System.Drawing.Size(509, 440);
			this.flowLayoutPanel.TabIndex = 7;
			// 
			// panelBattleLog
			// 
			this.panelBattleLog.Controls.Add(this.laBattleLogCaption);
			this.panelBattleLog.Controls.Add(this.tbBattleLog);
			this.panelBattleLog.Location = new System.Drawing.Point(669, 64);
			this.panelBattleLog.Name = "panelBattleLog";
			this.panelBattleLog.Size = new System.Drawing.Size(254, 472);
			this.panelBattleLog.TabIndex = 5;
			// 
			// panelBottom
			// 
			this.panelBottom.Controls.Add(this.btnRunSimulation);
			this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panelBottom.Location = new System.Drawing.Point(0, 587);
			this.panelBottom.Name = "panelBottom";
			this.panelBottom.Size = new System.Drawing.Size(935, 45);
			this.panelBottom.TabIndex = 6;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(362, 12);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(232, 29);
			this.label1.TabIndex = 7;
			this.label1.Text = "Robot Battle Arena";
			// 
			// RobotWarView
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(935, 632);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.panelBottom);
			this.Controls.Add(this.panelBattleLog);
			this.Controls.Add(this.panelBattleArena);
			this.Name = "RobotWarView";
			this.Text = "Robot Wars";
			this.panelBattleArena.ResumeLayout(false);
			this.panelBattleLog.ResumeLayout(false);
			this.panelBattleLog.PerformLayout();
			this.panelBottom.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.TextBox tbBattleLog;
		private System.Windows.Forms.Button btnRunSimulation;
		private System.Windows.Forms.Label laBattleLogCaption;
		private System.Windows.Forms.Panel panelBattleArena;
		private System.Windows.Forms.Panel panelBattleLog;
		private System.Windows.Forms.Panel panelBottom;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.Label label1;
	}
}

