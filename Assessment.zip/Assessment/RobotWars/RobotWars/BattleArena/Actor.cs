﻿using RobotWars.BattleArena.Actions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars.BattleArena
{
	/// <summary>
	/// An actor can be placed on cells on the battle arena,
	/// and can execute actions.
	/// </summary>
	public class Actor
	{
		/// <summary>
		/// The direction the actor is currently facing.
		/// </summary>
		public FaceDirections FacingDirection { get; set; }

		public string Name { get; set; }

		/// <summary>
		/// The cell currently occupied by the actor.
		/// </summary>
		public BattleArenaCell Cell { get; set; }

		public Queue<ActionCommand> ActionQueue = new Queue<ActionCommand>();

		public Actor(string name)
		{
			this.Name = name;
		}

		public void AddAction(ActionCommand action)
		{
			ActionQueue.Enqueue(action);
		}
	}
}
