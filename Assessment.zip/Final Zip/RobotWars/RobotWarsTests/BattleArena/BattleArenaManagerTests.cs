﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RobotWars.BattleArena;
using RobotWarsTests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars.BattleArena.Tests
{
	public class BattleArenaViewTest : IRobotWarView
	{
		public void Reset()
		{
		}

		public void CreateCell(BattleArenaCell cell)
		{
		}

		public void CreateGrid(List<BattleArenaCell> cells)
		{
		}

		public void PrintToCombatLog(string newLine)
		{
		}

		public void UpdateCell(BattleArenaCell cell)
		{
		}
	}

	public struct ActorMovementResult
	{
		public int PositionX { get; set; }
		public int PositionY { get; set; }
		public FaceDirections FacingDirection { get; set; }

		public ActorMovementResult(int x, int y, FaceDirections direction)
		{
			this.PositionX = x;
			this.PositionY = y;
			this.FacingDirection = direction;
		}
	}

	[TestClass()]
	public class RobotWarManagerTests
	{
		static BattleArenaManager manager;

		static ActorMovementResult robot1ExpectedPosition;
		static ActorMovementResult robot2ExpectedPosition;

		[TestMethod()]
		public void Simulate()
		{
			// Arrange
			BattleArenaViewTest view = new BattleArenaViewTest();
			manager = new BattleArenaManager(view, 0);
			string inputData = Resources.RobotWarTestInput_Valid;

			robot1ExpectedPosition = new ActorMovementResult(1, 3, FaceDirections.North);
			robot2ExpectedPosition = new ActorMovementResult(5, 1, FaceDirections.East);
			int expectedCellCount = 36;

			// Act
			manager.RunSimulation(inputData);

			// Assert
			Assert.AreEqual(expectedCellCount, manager.Cells.Count);
		}

		[TestMethod()]
		public void IsRobot1Valid()
		{
			ValidateActor(manager.Actors[0]);
		}

		[TestMethod()]
		public void IsRobot2Valid()
		{
			ValidateActor(manager.Actors[1]);
		}

		[TestMethod()]
		public void IsRobot1PositionValid()
		{
			// Arrange
			Actor robot1 = manager.Actors[0];

			// Assert
			ValidateActorPosition(robot1, robot1ExpectedPosition);
		}

		[TestMethod()]
		public void IsRobot2PositionValid()
		{
			// Arrange
			Actor robot2 = manager.Actors[1];

			// Assert
			ValidateActorPosition(robot2, robot2ExpectedPosition);
		}

		private void ValidateActor(Actor actor)
		{
			// Assert
			Assert.IsFalse(actor == null);
			Assert.IsFalse(actor.Cell == null);
		}

		private void ValidateActorPosition(Actor actor, ActorMovementResult expectedResult)
		{
			// Assert
			Assert.AreEqual(actor.Cell.X, expectedResult.PositionX);
			Assert.AreEqual(actor.Cell.Y, expectedResult.PositionY);
			Assert.AreEqual(actor.FacingDirection, expectedResult.FacingDirection);
		}
	}
}