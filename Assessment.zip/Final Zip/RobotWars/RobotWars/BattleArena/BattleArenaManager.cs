﻿using RobotWars.BattleArena.Actions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace RobotWars.BattleArena
{
	/// <summary>
	/// The main class responsible for running the robot war, and creating a bridge between different components.
	/// </summary>
	public class BattleArenaManager
	{
		#region Fields and properties

		public List<Actor> Actors { get; set; }
		public List<BattleArenaCell> Cells { get; set; }

		private static BattleArenaManager instance;
		public static BattleArenaManager Instance
		{
			get
			{
				return instance;
			}
			set
			{
				instance = value;
			}
		}

		public IRobotWarView View { get; set; }

		/// <summary>
		/// The wait time between executing actions (in ms).
		/// </summary>
		public int ActionDelay { get; set; }

		public bool SimulationInProgress { get; set; }

		#endregion Fields and properties

		public BattleArenaManager(IRobotWarView view, int actionDelay = 500)
		{
			if (instance == null)
				instance = this;

			this.ActionDelay = actionDelay;
			this.View = view;
			Actors = new List<Actor>();
			Cells = new List<BattleArenaCell>();
		}

		#region Public methods

		/// <summary>
		/// Starts the simulation. It's an asyncronous call so that the UI doesn't freeze during its execution.
		/// </summary>
		/// <param name="inputData"></param>
		public async void RunSimulation(string inputData)
		{
			SimulationInProgress = true;
			ParseInputData(inputData);

			foreach (Actor actor in Actors)
			{
				await ProcessActorActions(actor);
			}

			SimulationInProgress = false;
			View.PrintToCombatLog("Simulation finished.");
		}

		public BattleArenaCell GetCellByCoords(int x, int y)
		{
			return Cells.Find(c => c.X == x && c.Y == y);
		}

		public void UpdateCell(BattleArenaCell cell)
		{
			View.UpdateCell(cell);
		}

		#endregion Public methods

		#region Input parsing

		/// <summary>
		/// Parses the input data and sets up the Battle Arena using the data.
		/// </summary>
		/// <param name="input"></param>
		private void ParseInputData(string input)
		{
			int arenaXMax = 0;
			int arenaYMax = 0;

			// Getting rid of format string parameters and replacing them with spaces
			input = Regex.Replace(input, @"\s+", " ");

			try
			{
				ParseNextUint(ref input, out arenaXMax);
				ParseNextUint(ref input, out arenaYMax);
				
				// Building the level
				for (int y = arenaYMax; y >= 0; y--) // Y needs to be processed in a reversed order, because FlowLayoutPanel doesn't support BottomUp-LeftRight direction
				{
					for (int x = 0; x <= arenaXMax; x++)
					{
						Cells.Add(new BattleArenaCell(x, y));
					}
				}

				View.CreateGrid(Cells);

				// The rest of the data should be robot-related information
				while (input.Length > 0)
				{
					int robotXCoord = 0;
					int robotYCoord = 0;

					ParseNextUint(ref input, out robotXCoord);
					ParseNextUint(ref input, out robotYCoord);

					Actor actor = new Actor("Robot " + (Actors.Count + 1).ToString());
					BattleArenaCell occupiedCell = GetCellByCoords(robotXCoord, robotYCoord);
					ParseFacingDirection(ref input, actor);
					occupiedCell.TryPlaceActor(actor);
					Actors.Add(actor);

					if (occupiedCell == null)
						throw new Exception("The starting coordinates of an actor are invalid, and are out of the boundaries of the battle arena.");

					if(occupiedCell.TryPlaceActor(actor))
						throw new Exception("Couldn't place actor because its cell is already occupied. Please make sure actors are placed on different cells!");

					View.PrintToCombatLog(string.Format("Successfully spawned actor {0} at Cell {1}.",
						actor.Name, occupiedCell));

					ParseNextActions(ref input, actor);
				}
			}
			catch(Exception ex)
			{
				throw (ex);
			}
		}

		/// <summary>
		/// Tries to parse to UINT the first characters before a space is encountered.
		/// </summary>
		/// <param name="input"></param>
		/// <param name="result"></param>
		/// <returns>Whether the parse was successful</returns>
		private void ParseNextUint(ref string input, out int result)
		{
			result = 0;

			int excessCharacters = 0;
			string substring = SubstringNextSpaceOrEnd(input, out excessCharacters);
			
			if(Int32.TryParse(substring, out result))
			{
				// Removing the successfully parsed part of our string
				int removeLength = substring.Length + excessCharacters;
				input = input.Substring(removeLength, input.Length - removeLength);
			}
			else
			{
				throw new ArgumentException("The input data was not in the correct format: " + input);
			}
		}

		private void ParseFacingDirection(ref string input, Actor actor)
		{
			int excessCharacters = 0;
			string substring = SubstringNextSpaceOrEnd(input, out excessCharacters);

			switch (substring)
			{
				case "N":
					actor.FacingDirection = FaceDirections.North;
					break;
				case "E":
					actor.FacingDirection = FaceDirections.East;
					break;
				case "S":
					actor.FacingDirection = FaceDirections.South;
					break;
				case "W":
					actor.FacingDirection = FaceDirections.West;
					break;
				default:
					throw new ArgumentException(string.Format("Couldn't recognize the character facing direction parameter '{0}' in the input data.", substring));
			}

			int removeLength = substring.Length + excessCharacters;
			input = input.Remove(0, removeLength);
		}

		/// <summary>
		/// Looks for recognizable action codes in the given string, and assigns them to specified actor
		/// as ActionCommands.
		/// </summary>
		/// <param name="input">The string to look for action codes in</param>
		/// <param name="actor">The Actor whom the actions should be assigned to</param>
		private void ParseNextActions(ref string input, Actor actor)
		{
			int excessCharacters = 0;
			string substring = SubstringNextSpaceOrEnd(input, out excessCharacters);

			foreach (Char c in substring)
			{
				ActionCommand newAction = null;

				switch (c)
				{
					case 'M':
						newAction = new MoveAction(actor);
						break;
					case 'L':
						newAction = new RotateAction(actor, RotateDirections.Left);
						break;
					case 'R':
						newAction = new RotateAction(actor, RotateDirections.Right);
						break;
					default:
						throw new ArgumentException(string.Format("Couldn't recognize the action parameter '{0}' in the input data.", c));
				}

				if (newAction != null)
					actor.AddAction(newAction);
			}

			int removeLength = substring.Length + excessCharacters;
			input = input.Remove(0, removeLength);
		}

		/// <summary>
		/// Returns a substring that contains all characters until the first occurence of a space,
		/// a newline string format or until the string ends.
		/// </summary>
		/// <param name="input">The text data</param>
		/// <param name="excessCharacters">Returns the number of extra characters at the end of the string</param>
		/// <returns>The new substring</returns>
		private string SubstringNextSpaceOrEnd(string input, out int excessCharacters)
		{
			int endIndex = input.IndexOf(" ");

			// A space was found
			if (endIndex != -1)
			{
				excessCharacters = 1;
			}
			else
			{ 
				// If we find no space or other format strings, 
				// then we read all the way to the end of the input
				endIndex = input.Length;
				excessCharacters = 0;
			}

			return input.Substring(0, endIndex);
		}

		#endregion Input parsing

		private async Task<int> ProcessActorActions(Actor actor)
		{
			int queueLength = actor.ActionQueue.Count;

			for (int i = 0; i < queueLength; i++)
			{
				ActionCommand action = actor.ActionQueue.Peek();
				action.Execute();
				View.PrintToCombatLog(action.ToString());
				actor.ActionQueue.Dequeue();
				await Task.Delay(ActionDelay);
			}

			return 11;
		}
	}
}