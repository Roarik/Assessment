﻿using RobotWars.BattleArena;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RobotWars
{
	/// <summary>
	/// The WinForms representation of RobotWar.
	/// </summary>
	public partial class RobotWarView : Form, IRobotWarView
	{
		#region Fields and properties

		/// <summary>
		/// The default image a cell should display if it's empty.
		/// </summary>
		public Image DefaultImage { get; set; }

		public Dictionary<BattleArenaCell, PictureBox> cellPictures = new Dictionary<BattleArenaCell, PictureBox>();

		public static RobotWarView instance;
		public static RobotWarView Instance
		{
			get
			{
				return instance;
			}
			set
			{
				instance = value;
			}
		}

		public BattleArenaManager Manager { get; set; }

		private const int cellSize = 40;

		#endregion Fields and properties

		public RobotWarView()
		{
			InitializeComponent();
			DefaultImage = Resources.CellImage;
		}

		public void Reset()
		{
			for (int i = 0; i < flowLayoutPanel.Controls.Count; i++)
			{
				flowLayoutPanel.Controls.Remove(flowLayoutPanel.Controls[i]);
			}

			tbBattleLog.Text = string.Empty;
			cellPictures.Clear();
		}

		#region Grid generation

		public void CreateGrid(List<BattleArenaCell> cells)
		{
			foreach (BattleArenaCell cell in cells)
			{
				CreateCell(cell);
			}

			// Resizing the flow layout panel
			int rowCount = (int)cells.Max(c => c.Y) + 1;
			int columnCount = (int)cells.Max(c => c.X) + 1;
			int horizontalPadding = flowLayoutPanel.Padding.Left + flowLayoutPanel.Padding.Right + flowLayoutPanel.Margin.Top + flowLayoutPanel.Margin.Bottom;
			int verticalPadding = flowLayoutPanel.Padding.Bottom + flowLayoutPanel.Padding.Top + flowLayoutPanel.Margin.Left + flowLayoutPanel.Margin.Right;

			flowLayoutPanel.Size = new Size(
				columnCount * (cellSize + horizontalPadding), 
				rowCount * (cellSize + verticalPadding));
		}

		public void CreateCell(BattleArenaCell cell)
		{
			PictureBox picture = new PictureBox()
			{
				Image = DefaultImage,
				Size = new Size(cellSize, cellSize),
				SizeMode = PictureBoxSizeMode.StretchImage,
				BackColor = Color.Gray
			};

			// The tooltip displays the cell coordinates
			toolTip.SetToolTip(picture, cell.ToString());
			flowLayoutPanel.Controls.Add(picture);
			cellPictures.Add(cell, picture);
		}

		#endregion Grid generation

		public void UpdateCell(BattleArenaCell cell)
		{
			PictureBox picture = cellPictures[cell];

			if (picture == null)
				return;

			if (cell.OccupyingActor != null)
			{
				// This part would be more elegant with transform rotation instead of image swap,
				// but that seemed too complicated to worth the time delving into right now
				switch (cell.OccupyingActor.FacingDirection)
				{
					case FaceDirections.North:
						picture.Image = Resources.RobotBoy_North;
						break;
					case FaceDirections.West:
						picture.Image = Resources.RobotBoy_West;
						break;
					case FaceDirections.South:
						picture.Image = Resources.RobotBoy_South;
						break;
					case FaceDirections.East:
						picture.Image = Resources.RobotBoy_East;
						break;
				}
			}
			else
			{
				picture.Image = DefaultImage;
				picture.Image.RotateFlip(RotateFlipType.RotateNoneFlipNone);
			}
		}

		public void PrintToCombatLog(string newLine)
		{
			tbBattleLog.Text += newLine + Environment.NewLine;
		}

		#region Event handlers

		private void btnRunSimulation_Click(object sender, EventArgs e)
		{
			try
			{
				Reset();
				Manager = new BattleArenaManager(this);
				Manager.RunSimulation(Resources.DefaultInput);
				btnRunSimulation.Enabled = false;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		#endregion Event handlers
	}
}