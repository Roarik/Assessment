﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars.BattleArena
{
	/// <summary>
	/// Cells comprise the grid of the battle arena. This class is stores the cell's respective data,
	/// and 
	/// </summary>
	public class BattleArenaCell
	{
		#region Fields and properties

		public int X { get; set; }
		public int Y { get; set; }
		public Actor OccupyingActor { get; private set; }

		#endregion Fields and properties

		public BattleArenaCell(int x, int y)
		{
			this.X = x;
			this.Y = y;
			this.OccupyingActor = null;
		}

		#region Public methods

		/// <summary>
		/// Tries to place the specified actor on this cell.
		/// </summary>
		/// <param name="actor"></param>
		/// <returns>True if the placement was successful.</returns>
		public bool TryPlaceActor(Actor actor)
		{
			bool isOccupied = OccupyingActor != null;

			if (!isOccupied)
			{
				OccupyingActor = actor;

				if (OccupyingActor.Cell != null)
					OccupyingActor.Cell.RemoveOccupyingActor();

				OccupyingActor.Cell = this;
				BattleArenaManager.Instance.UpdateCell(this);
			}

			return !isOccupied;
		}

		/// <summary>
		/// Removes the occupying actor - if any - from the cell.
		/// </summary>
		public void RemoveOccupyingActor()
		{
			if (OccupyingActor != null)
			{
				OccupyingActor.Cell = null;
				OccupyingActor = null;

				BattleArenaManager.Instance.UpdateCell(this);
			}
		}

		public override string ToString()
		{
			return string.Format("({0},{1})", X, Y);
		}

		#endregion Public methods
	}
}
