﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars.BattleArena
{
	/// <summary>
	/// The possible directions Actors can rotate on the 2D battle arena.
	/// </summary>
	public enum RotateDirections
	{
		Left,
		Right
	}

	/// <summary>
	/// The possible cardinal directions Actors can face on the 2D battle arena.
	/// </summary>
	public enum FaceDirections
	{
		North,
		West,
		South,
		East
	}
}
