﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars.BattleArena.Actions
{
	/// <summary>
	/// Rotates the actor.
	/// </summary>
	class RotateAction : ActionCommand
	{
		public RotateDirections RotateDirection { get; set; }

		public RotateAction(Actor actor, RotateDirections rotateDirection) : base(actor)
		{
			this.RotateDirection = rotateDirection;
		}

		public override void Execute()
		{
			FaceDirections newDirection = Actor.FacingDirection;

			switch (RotateDirection)
			{
				case RotateDirections.Left:
					{
						switch (Actor.FacingDirection)
						{
							case FaceDirections.North:
								newDirection = FaceDirections.West;
								break;
							case FaceDirections.West:
								newDirection = FaceDirections.South;
								break;
							case FaceDirections.South:
								newDirection = FaceDirections.East;
								break;
							case FaceDirections.East:
								newDirection = FaceDirections.North;
								break;
						}
					}
					break;
				case RotateDirections.Right:
					{
						switch (Actor.FacingDirection)
						{
							case FaceDirections.North:
								newDirection = FaceDirections.East;
								break;
							case FaceDirections.West:
								newDirection = FaceDirections.North;
								break;
							case FaceDirections.South:
								newDirection = FaceDirections.West;
								break;
							case FaceDirections.East:
								newDirection = FaceDirections.South;
								break;
						}
					}
					break;
			}

			Actor.FacingDirection = newDirection;
			BattleArenaManager.Instance.UpdateCell(Actor.Cell);

			IsExecuted = true;
		}

		public override string ToString()
		{
			if (!IsExecuted)
				return "Not yet executed.";

			return string.Format(
				string.Format("{0} rotated {1}. New direction: {2}.",
				Actor.Name, RotateDirection, Actor.FacingDirection));
		}
	}
}
