﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars.BattleArena.Actions
{
	/// <summary>
	/// Moves an actor from one cell to another.
	/// </summary>
	class MoveAction : ActionCommand
	{
		private BattleArenaCell originalCell;
		private BattleArenaCell targetCell;

		public MoveAction(Actor actor) : base(actor)
		{
		}

		public override void Execute()
		{
			if (Actor.Cell == null)
				return;

			originalCell = Actor.Cell;
			int targetX = originalCell.X;
			int targetY = originalCell.Y;

			switch (Actor.FacingDirection)
			{
				case FaceDirections.North:
					targetY++;
					break;
				case FaceDirections.South:
					targetY--;
					break;
				case FaceDirections.East:
					targetX++;
					break;
				case FaceDirections.West:
					targetX--;
					break;
			}

			targetCell = BattleArenaManager.Instance.GetCellByCoords(targetX, targetY);

			if (targetCell == null)
			{
				return;
			}
			else if(targetCell.OccupyingActor != null)
			{
				return;
			}
			else
			{
				targetCell.TryPlaceActor(Actor);
			}

			IsExecuted = true;
		}

		public override string ToString()
		{
			if (!IsExecuted || originalCell == null || targetCell == null)
				return "Not yet executed.";

			return string.Format("{0} moved from Cell {1} to Cell {2}.",
				Actor.Name, originalCell.ToString(), targetCell.ToString());
		}
	}
}
