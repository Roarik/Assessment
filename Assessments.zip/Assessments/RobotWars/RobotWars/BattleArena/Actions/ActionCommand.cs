﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars.BattleArena.Actions
{
	/// <summary>
	/// Base class for actions the Actors can execute. Implements the Command pattern.
	/// </summary>
	public abstract class ActionCommand
	{
		public Actor Actor { get; private set; }

		public bool IsExecuted { get; protected set; }

		public ActionCommand(Actor actor)
		{
			this.Actor = actor;
		}

		public abstract void Execute();
	}
}
