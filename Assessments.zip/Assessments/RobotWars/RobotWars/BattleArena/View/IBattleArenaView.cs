﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars.BattleArena
{
	/// <summary>
	/// Provides an interface for displaying data provided by the RobotWarManager.
	/// </summary>
	public interface IBattleArenaView
	{
		/// <summary>
		/// Resets the view, preparing it for multiple executions.
		/// </summary>
		void Reset();

		/// <summary>
		/// Creates a visual grid comprising of cells.
		/// </summary>
		/// <param name="cells"></param>
		void CreateGrid(List<BattleArenaCell> cells);

		/// <summary>
		/// Creates a visual representation for a cell.
		/// </summary>
		/// <param name="cell"></param>
		void CreateCell(BattleArenaCell cell);

		/// <summary>
		/// Updates the cell's representation.
		/// </summary>
		/// <param name="cell"></param>
		void UpdateCell(BattleArenaCell cell);

		/// <summary>
		/// Displays combat information to the player.
		/// </summary>
		/// <param name="newLine"></param>
		void PrintToCombatLog(string newLine);
	}
}
