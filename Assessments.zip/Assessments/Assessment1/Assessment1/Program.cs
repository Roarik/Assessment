﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment1
{
	class Program
	{
		// This data would ideally come from other sources (e.g. database, a file or network stream etc.), 
		// but I'll just work with hardcoded values for the sake of the assessment.
		public static List<string> expressions = new List<string>()
		{
			"al", "albums", "aver", "bar", "barely", "be", "befoul", "bums", "by", "cat", "con", "convex", "ely", "foul", "here", "hereby", "jig", "jigsaw", "or", "saw", "tail", "tailor", "vex", "we", "weaver"
		};

		static void Main(string[] args)
		{
			// Printing out the input
			Console.WriteLine("The list of input expressions:");
			Console.WriteLine("\"{0}\"\n", string.Join(", ", expressions));

			// Making the actual call
			int lengthFilter = 6;
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			List<string> matches = CombinedExpressionUtils.FilterCombinedExpressions(expressions, lengthFilter);
			stopwatch.Stop();

			// Printing the result
			Console.WriteLine("The filtered result (only {0} character long expressions):", lengthFilter);
			Console.WriteLine("\"{0}\"\n", string.Join(", ", matches));
			Console.WriteLine("The operation took {0} milliseconds.", stopwatch.ElapsedMilliseconds);
			Console.ReadLine();
		}
	}
}
